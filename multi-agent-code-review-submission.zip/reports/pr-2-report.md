# 🔍 Code Review Report

## Summary

| Metric | Value |
|--------|-------|
| **Overall Score** | 15/100 |
| **Files Reviewed** | 1 |
| **Critical Issues** | 3 |
| **High Priority Tests** | 3 |
| **Refactoring Opportunities** | 3 |

## 🎯 Top Recommendations

1. 🚨 **Security**: Reject PR and require rewrite using parameterized queries for all SQL operations. All three functions vulnerable to SQL injection.
   - Files: src/todo.ts

2. 🚨 **Testing**: Add comprehensive test suite covering SQL injection attempts, input validation boundaries, and happy path functionality.
   - Files: src/todo.ts

3. ⚠️ **Code Quality**: Add input validation for all function parameters and implement consistent error handling with try-catch blocks.
   - Files: src/todo.ts

4. ⚠️ **Type Safety**: Fix type mismatch in searchTodosByStatus: change completed parameter from string to boolean.
   - Files: src/todo.ts

5. 📝 **Code Consistency**: Extract common db.query pattern into helper function to reduce duplication and ensure consistent error handling.
   - Files: src/todo.ts

## 📁 File Details

### 📄 `src/todo.ts`

**Quality Score:** 15/100 | **Coverage:** ~0%

#### Issues (3)
  - Line 118: `critical` SQL injection via template literal in searchTodos(). Keyword parameter directly interpolated into LIKE clause without parameterization.
  - Line 127: `critical` SQL injection via string concatenation in searchTodosByStatus(). Completed parameter concatenated without validation or parameterization.
  - Line 136: `critical` SQL injection via template literal in getTodosByUser(). UserId parameter directly interpolated without parameterization, risking privilege escalation.


#### Test Gaps (3)
  - `searchTodos() - SQL injection with OR clause` (critical priority)
  - `searchTodosByStatus() - SQL injection with DROP statement` (critical priority)

  *...and 1 more*

#### Refactoring Opportunities (3)
  - **pattern-improvement**: Migrate all SQL concatenation to parameterized queries for consistency with existing codebase (createTodo, getTodoById).
  - **extract-function**: Extract repeated db.query() and type casting pattern into reusable helper function.

  *...and 1 more*

---

### 📄 `tests/placeholder`

**Quality Score:** 0/100 | **Coverage:** ~0%

#### Issues (0)
  None found


#### Test Gaps (0)
  None found


#### Refactoring Opportunities (0)
  None found


---

*Generated at 2026-10-29T00:00:00Z • Duration: 126739ms*
