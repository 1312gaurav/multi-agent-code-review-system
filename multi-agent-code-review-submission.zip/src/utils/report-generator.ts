import { ReviewReport } from '../types/report-types';

/**
 * Report Generator
 * Converts ReviewReport to various output formats (Markdown, HTML, JSON)
 */
export class ReportGenerator {
  /**
   * Generate a Markdown report for PR comments
   */
  generateMarkdownReport(report: ReviewReport): string {
    const { summary, recommendations, fileReviews } = report;

    const formattedRecs = recommendations.slice(0, 5).map((rec, idx) => {
      const emoji = {
        critical: '🚨',
        high: '⚠️',
        medium: '📝',
        low: '💡'
      }[rec.priority];

      return `${idx + 1}. ${emoji} **${rec.category}**: ${rec.description}
   - Files: ${rec.files.join(', ')}`;
    }).join('\n\n');

    const formattedFiles = fileReviews.map(review => {
      const { file, codeQuality, testCoverage, refactorings } = review;

      const issueList = codeQuality.issues.slice(0, 3)
        .map(i => `  - Line ${i.line}: \`${i.severity}\` ${i.description}`)
        .join('\n');

      const testList = testCoverage.untestedPaths.slice(0, 2)
        .map(p => `  - \`${p.location}\` (${p.priority} priority)`)
        .join('\n');

      const refactorList = refactorings.suggestions.slice(0, 2)
        .map(s => `  - **${s.type}**: ${s.description}`)
        .join('\n');

      return `### 📄 \`${file}\`

**Quality Score:** ${codeQuality.overallScore}/100 | **Coverage:** ~${testCoverage.coverageEstimate}%

#### Issues (${codeQuality.issues.length})
${issueList || '  None found'}
${codeQuality.issues.length > 3 ? `\n  *...and ${codeQuality.issues.length - 3} more*` : ''}

#### Test Gaps (${testCoverage.untestedPaths.length})
${testList || '  None found'}
${testCoverage.untestedPaths.length > 2 ? `\n  *...and ${testCoverage.untestedPaths.length - 2} more*` : ''}

#### Refactoring Opportunities (${refactorings.suggestions.length})
${refactorList || '  None found'}
${refactorings.suggestions.length > 2 ? `\n  *...and ${refactorings.suggestions.length - 2} more*` : ''}`;
    }).join('\n\n---\n\n');

    return `# 🔍 Code Review Report

## Summary

| Metric | Value |
|--------|-------|
| **Overall Score** | ${summary.overallScore}/100 |
| **Files Reviewed** | ${summary.totalFiles} |
| **Critical Issues** | ${summary.criticalIssues} |
| **High Priority Tests** | ${summary.highPriorityTests} |
| **Refactoring Opportunities** | ${summary.refactoringOpportunities} |

## 🎯 Top Recommendations

${formattedRecs || 'No recommendations at this time.'}

## 📁 File Details

${formattedFiles}

---

*Generated at ${report.metadata.analyzedAt} • Duration: ${report.metadata.duration}ms*
`;
  }

  /**
   * Generate an HTML report for web display
   */
  generateHTMLReport(report: ReviewReport): string {
    const { summary, recommendations, metadata, fileReviews } = report;

    const escapeHTML = (value: unknown): string =>
      String(value ?? '').replace(/[&<>"']/g, char => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      })[char] || char);

    const recList = recommendations.slice(0, 5).map(r => `
      <li>
        <strong>[${escapeHTML(r.priority.toUpperCase())}]
        ${escapeHTML(r.category)}</strong>:
        ${escapeHTML(r.description)}
        <br><small>Files: ${escapeHTML(r.files.join(', '))}</small>
      </li>
    `).join('');

    const fileDetails = fileReviews.map(review => {
      const { file, codeQuality, testCoverage, refactorings } = review;

      const issues = codeQuality.issues.map(issue => `
        <li>
          <strong>${escapeHTML(issue.severity)}</strong>
          (line ${escapeHTML(issue.line)}):
          ${escapeHTML(issue.description)}
        </li>
      `).join('');

      const testGaps = testCoverage.untestedPaths.map(gap => `
        <li>
          <strong>${escapeHTML(gap.priority)} priority</strong>:
          ${escapeHTML(gap.location)}
        </li>
      `).join('');

      const suggestions = refactorings.suggestions.map(suggestion => `
        <li>
          <strong>${escapeHTML(suggestion.type)}</strong>:
          ${escapeHTML(suggestion.description)}
        </li>
      `).join('');

      return `
        <section class="file-review">
          <h3>${escapeHTML(file)}</h3>
          <p>
            <strong>Quality:</strong> ${escapeHTML(codeQuality.overallScore)}/100
            |
            <strong>Estimated Coverage:</strong>
            ${escapeHTML(testCoverage.coverageEstimate)}%
          </p>

          <h4>Code Quality Issues (${codeQuality.issues.length})</h4>
          <ul>${issues || '<li>None found</li>'}</ul>

          <h4>Test Coverage Gaps (${testCoverage.untestedPaths.length})</h4>
          <ul>${testGaps || '<li>None found</li>'}</ul>

          <h4>Refactoring Suggestions (${refactorings.suggestions.length})</h4>
          <ul>${suggestions || '<li>None found</li>'}</ul>
        </section>
      `;
    }).join('');

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Code Review Report</title>
  <style>
    * { box-sizing: border-box; }
    body {
      font-family: Arial, sans-serif;
      max-width: 1000px;
      margin: 0 auto;
      padding: 24px;
      background: #f8f9fa;
      color: #212529;
    }
    h1 { color: #2c3e50; border-bottom: 3px solid #3498db; }
    h2 { margin-top: 32px; }
    h3 { overflow-wrap: anywhere; }
    .summary {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 16px;
      margin: 24px 0;
    }
    .metric, .file-review {
      background: white;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 16px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.07);
    }
    .metric { text-align: center; }
    .metric-value {
      font-size: 2em;
      font-weight: bold;
      color: #3498db;
    }
    .metric-label { color: #6c757d; }
    ul { padding-left: 24px; }
    li { margin: 8px 0; overflow-wrap: anywhere; }
    footer {
      text-align: center;
      color: #6c757d;
      margin-top: 32px;
    }
  </style>
</head>
<body>
  <h1>Code Review Report</h1>

  <div class="summary">
    <div class="metric">
      <div class="metric-value">${summary.overallScore}</div>
      <div class="metric-label">Overall Score</div>
    </div>
    <div class="metric">
      <div class="metric-value">${summary.totalFiles}</div>
      <div class="metric-label">Files Reviewed</div>
    </div>
    <div class="metric">
      <div class="metric-value">${summary.criticalIssues}</div>
      <div class="metric-label">Critical Issues</div>
    </div>
    <div class="metric">
      <div class="metric-value">${summary.highPriorityTests}</div>
      <div class="metric-label">Tests Needed</div>
    </div>
    <div class="metric">
      <div class="metric-value">${summary.refactoringOpportunities}</div>
      <div class="metric-label">Refactorings</div>
    </div>
  </div>

  <h2>Top Recommendations</h2>
  <ul>${recList || '<li>No recommendations at this time.</li>'}</ul>

  <h2>File Details</h2>
  ${fileDetails || '<p>No file reviews available.</p>'}

  <footer>
    Generated at ${escapeHTML(metadata.analyzedAt)}
    | Duration: ${escapeHTML(metadata.duration)}ms
  </footer>
</body>
</html>`;
  }

  /**
   * Generate formatted JSON report
   */
  generateJSONReport(report: ReviewReport): string {
    return JSON.stringify(report, null, 2);
  }
}
