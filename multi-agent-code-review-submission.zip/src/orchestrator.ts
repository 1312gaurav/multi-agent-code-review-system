import { query, type Options } from '@anthropic-ai/claude-agent-sdk';
import {
  ReviewReportSchema,
  ReviewReportJSONSchema,
  type ReviewReport
} from './types/report-types';

import {
  codeQualityAnalyzer,
  testCoverageAnalyzer,
  refactoringSuggester
} from './agents';

import { mcpServersConfig } from './config/mcp.config';
import { RateLimiter, withRateLimit } from './utils/rate-limiter';
import { withRetry } from './utils/error-handler';


/**
 * Configuration for the Code Review Orchestrator.
 */
export interface OrchestratorOptions {
  model?: string;
  maxTurns?: number;
}

/**
 * Coordinates specialized agents to review GitHub pull requests.
 */
export class CodeReviewOrchestrator {
  private options: OrchestratorOptions;
  private rateLimiter = new RateLimiter({
    maxConcurrent: 1
  });

  constructor(options: OrchestratorOptions = {}) {
    this.options = options;
  }

  /**
   * Build the configuration passed to the Claude Agent SDK.
   */
  private buildSdkOptions(): Options {
    return {
      model:
        this.options.model ||
        process.env.ANTHROPIC_MODEL ||
        'claude-sonnet-4-5-20250929',

      maxTurns: this.options.maxTurns ?? 30,

      agents: {
        'code-quality-analyzer': codeQualityAnalyzer,
        'test-coverage-analyzer': testCoverageAnalyzer,
        'refactoring-suggester': refactoringSuggester
      },

      allowedTools: [
        'Task',
        'Read',
        'Grep',
        'Glob',
        'mcp__github__*',
        'mcp__eslint__*'
      ],

      mcpServers: mcpServersConfig,

      permissionMode: 'bypassPermissions',
      allowDangerouslySkipPermissions: true
    };
  }

  /**
   * Review a pull request using specialized agents.
   */
  async reviewPullRequest(
    owner: string,
    repo: string,
    prNumber: number
  ): Promise<ReviewReport> {
    if (!owner.trim() || !repo.trim()) {
      throw new Error('Repository owner and name are required');
    }

    if (!Number.isInteger(prNumber) || prNumber <= 0) {
      throw new Error('Pull request number must be a positive integer');
    }

    const prompt = `
Review GitHub pull request ${owner}/${repo}#${prNumber}.

Use the GitHub MCP tools to retrieve the pull request and changed files.

Delegate the review to all three specialized agents:
1. code-quality-analyzer
2. test-coverage-analyzer
3. refactoring-suggester

Review the actual changes, not unrelated repository files.

For each changed source file, combine the findings from all three
agents into one fileReviews entry.

Produce a complete report containing:
- pullRequest: owner, repo, and number
- fileReviews: codeQuality, testCoverage, and refactorings
- summary: totals and overall quality score
- recommendations: prioritized actionable improvements
- metadata: analysis timestamp, duration, and agent versions

Use only findings supported by the pull request content.
Do not invent issues, test files, or code locations.

Keep the final JSON concise:
- Include at most 3 code-quality issues per file.
- Include at most 3 untested paths per file.
- Include at most 3 refactoring suggestions per file.
- Include at most 5 overall recommendations.
- Use short descriptions and suggestions.
- Include every required field, even when an array is empty.
- Use the exact enum values required by the schema.
- Return one complete JSON object, not Markdown.

Return the final result using the required JSON schema.
`;

    const startedAt = Date.now();

    const sdkOptions: Options = {
      ...this.buildSdkOptions(),
      outputFormat: {
        type: 'json_schema',
        schema: ReviewReportJSONSchema
      }
    };

    return withRateLimit(
      this.rateLimiter,
      () => withRetry(async () => {
            for await (const message of query({
              prompt,
              options: sdkOptions
            })) {
              if (message.type !== 'result') {
                continue;
              }
        
              if (message.subtype !== 'success') {
                throw new Error(
                  'Claude review failed: ' + message.errors.join('; ')
                );
              }
        
              if (message.structured_output === undefined) {
                throw new Error('Claude returned no structured review output');
              }
        
              const validation = ReviewReportSchema.safeParse(
                message.structured_output
              );
        
              if (!validation.success) {
                throw new Error(
                  'Invalid review report: ' + validation.error.message
                );
              }
        
              const report = validation.data;
        
              // Ensure the report identifies the requested pull request.
              if (
                report.pullRequest.owner !== owner ||
                report.pullRequest.repo !== repo ||
                report.pullRequest.number !== prNumber
              ) {
                throw new Error('Review report references the wrong pull request');
              }
        
              report.metadata.duration = Date.now() - startedAt;
        
              return report;
            }
        
            throw new Error('Claude did not return a final review result');
      }, 0),
      1000
    );
  }
}
