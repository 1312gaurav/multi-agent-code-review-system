/**
 * Model Context Protocol (MCP) server configurations
 *
 * GitHub MCP: Fetches pull requests and repository data
 * ESLint MCP: Analyzes code quality and linting issues
 */

export const mcpServersConfig = {
  github: {
    type: 'stdio' as const,
    command: 'npx',
    args: [
      '-y',
      '@modelcontextprotocol/server-github'
    ],
    env: {
      GITHUB_PERSONAL_ACCESS_TOKEN:
        process.env.GITHUB_TOKEN || ''
    }
  },

  eslint: {
    type: 'stdio' as const,
    command: 'npx',
    args: [
      '-y',
      '@eslint/mcp@latest'
    ],
    env: {}
  }
};
