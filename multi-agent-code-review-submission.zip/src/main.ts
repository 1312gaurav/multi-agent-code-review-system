import * as dotenv from 'dotenv';
import { CodeReviewOrchestrator } from './orchestrator';
import { ReportGenerator } from './utils/report-generator';
import { mkdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

dotenv.config();

/**
 * Usage:
 * npm run dev -- <owner> <repo> <pr-number>
 */
async function main(): Promise<void> {
  const [owner, repo, prStr] = process.argv.slice(2);

  // Validate command-line arguments.
  if (!owner || !repo || !prStr) {
    console.error(
      'Usage: npm run dev -- <owner> <repo> <pr-number>'
    );
    process.exitCode = 1;
    return;
  }

  const prNumber = Number(prStr);

  if (!Number.isInteger(prNumber) || prNumber <= 0) {
    console.error(
      'Error: PR number must be a positive integer.'
    );
    process.exitCode = 1;
    return;
  }

  // Validate authentication.
  const hasAnthropicKey = Boolean(
    process.env.ANTHROPIC_API_KEY
  );

  const hasBedrockCredentials = Boolean(
    process.env.AWS_ACCESS_KEY_ID &&
    process.env.AWS_SECRET_ACCESS_KEY &&
    process.env.AWS_REGION
  );

  if (!hasAnthropicKey && !hasBedrockCredentials) {
    console.error(
      'Error: Configure ANTHROPIC_API_KEY or AWS credentials.'
    );
    process.exitCode = 1;
    return;
  }

  if (!process.env.ANTHROPIC_MODEL) {
    console.error(
      'Error: ANTHROPIC_MODEL is required in your environment.'
    );
    process.exitCode = 1;
    return;
  }

  console.log(
    hasAnthropicKey
      ? 'Using Anthropic API authentication'
      : 'Using AWS Bedrock authentication'
  );

  console.log(
    `Reviewing ${owner}/${repo} pull request #${prNumber}...`
  );

  try {
    const orchestrator = new CodeReviewOrchestrator();

    const report = await orchestrator.reviewPullRequest(
      owner,
      repo,
      prNumber
    );

    console.log('Review completed successfully!');
    console.log(
      JSON.stringify(report.summary, null, 2)
    );

    const generator = new ReportGenerator();
    const reportsDir = join(process.cwd(), 'reports');

    await mkdir(reportsDir, { recursive: true });

    const baseName = `pr-${prNumber}-report`;

    await Promise.all([
      writeFile(
        join(reportsDir, `${baseName}.json`),
        generator.generateJSONReport(report),
        'utf8'
      ),
      writeFile(
        join(reportsDir, `${baseName}.md`),
        generator.generateMarkdownReport(report),
        'utf8'
      ),
      writeFile(
        join(reportsDir, `${baseName}.html`),
        generator.generateHTMLReport(report),
        'utf8'
      )
    ]);

    console.log(`Reports saved to ${reportsDir}`);
    console.log(`- ${baseName}.json`);
    console.log(`- ${baseName}.md`);
    console.log(`- ${baseName}.html`);
  } catch (error) {
    console.error(
      'Review failed:',
      error instanceof Error ? error.message : String(error)
    );
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error('Unexpected error:', error);
  process.exitCode = 1;
});
